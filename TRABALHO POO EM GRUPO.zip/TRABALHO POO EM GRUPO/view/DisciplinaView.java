package view;

import model.Disciplina;
import java.util.List;
import java.util.Scanner;

public class DisciplinaView {

    private static final Scanner scanner = new Scanner(System.in);


    public static String GetCodigo() {
        System.out.print("\n Digite o CÓDIGO da disciplina: ");
        return scanner.nextLine();
    }


    public static void Criar(Disciplina disciplina) {
        System.out.println("\n--- Cadastro de Nova Disciplina ---");


        System.out.print("   Código da Disciplina : ");
        disciplina.setCodigo(scanner.nextLine());


        System.out.print("   Nome: ");
        disciplina.setNome(scanner.nextLine());


        System.out.print("   Carga Horária (em horas): ");
        try {
            int carga = Integer.parseInt(scanner.nextLine());
            disciplina.setCargaHoraria(carga);
        } catch (NumberFormatException e) {
            System.out.println(" Valor inválido para carga horária. Configurado para 0.");
            disciplina.setCargaHoraria(0);
        }


    }


    public static void Atualizar(Disciplina disciplina) {
        System.out.println("\n--- Atualizando Disciplina: " + disciplina.getCodigo() + " ---");
        System.out.println("   [Deixe em branco para manter o valor atual]");


        System.out.print("   Novo Nome (atual: " + disciplina.getNome() + "): ");
        String novoNome = scanner.nextLine();
        if (!novoNome.trim().isEmpty()) {
            disciplina.setNome(novoNome);
        }


        System.out.print("   Nova Carga Horária em horas (atual: " + disciplina.getCargaHoraria() + "): ");
        String cargaStr = scanner.nextLine();
        if (!cargaStr.trim().isEmpty()) {
            try {
                int carga = Integer.parseInt(cargaStr);
                disciplina.setCargaHoraria(carga);
            } catch (NumberFormatException e) {
                System.out.println(" Valor inválido. Carga horária não alterada.");
            }
        }
    }



    public static void Consultar(Disciplina disciplina) {
        System.out.println("\n--- Detalhes da Disciplina ---");
        if (disciplina == null) {
            System.out.println(" Disciplina não encontrada.");
        } else {
            System.out.println(disciplina.toString());

        }
    }


    public static void Listar(List<Disciplina> disciplinas) {
        System.out.println("\n--- Lista de Disciplinas Cadastradas (" + disciplinas.size() + ") ---");
        if (disciplinas.isEmpty()) {
            System.out.println("Nenhuma disciplina cadastrada.");
        } else {
            for (Disciplina disciplina : disciplinas) {
                System.out.println("  * " + disciplina.toString());
            }
        }
    }
}
