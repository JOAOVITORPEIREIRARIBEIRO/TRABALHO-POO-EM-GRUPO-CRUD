package controller;

import model.Disciplina;
import view.DisciplinaView;
import java.util.ArrayList;
import java.util.List;

public class DisciplinaController {


    private static final List<Disciplina> disciplinas = new ArrayList<>();

    public static void Criar() {
        Disciplina disciplina = new Disciplina();
        DisciplinaView.Criar(disciplina);




        if (disciplina != null && disciplina.getCodigo() != null && !disciplina.getCodigo().trim().isEmpty()) {


            if (disciplinas.stream().anyMatch(d -> d.getCodigo().equals(disciplina.getCodigo()))) {
                System.out.println(" Erro: Disciplina com código " + disciplina.getCodigo() + " já existe.");
                return;
            }


            disciplinas.add(disciplina);
            System.out.println(" Disciplina criada e salva em memória.");
        } else {
            System.out.println(" Criação de disciplina cancelada ou inválida.");
        }
    }

    public static void Consultar() {
        String codigo = DisciplinaView.GetCodigo();


        Disciplina disciplina = disciplinas.stream()
                .filter(d -> d.getCodigo().equals(codigo))
                .findFirst()
                .orElse(null);


        DisciplinaView.Consultar(disciplina);
    }

    public static void Listar() {

        DisciplinaView.Listar(disciplinas);
    }

    public static void Atualizar() {
        String codigo = DisciplinaView.GetCodigo();


        Disciplina disciplinaParaAtualizar = disciplinas.stream()
                .filter(d -> d.getCodigo().equals(codigo))
                .findFirst()
                .orElse(null);

        if (disciplinaParaAtualizar != null) {

            DisciplinaView.Atualizar(disciplinaParaAtualizar);

            System.out.println(" Disciplina atualizada com sucesso em memória.");
        } else {
            System.out.println(" Erro: Disciplina com código " + codigo + " não encontrada para atualização.");
        }
    }

    public static void Deletar() {
        String codigo = DisciplinaView.GetCodigo();


        boolean foiRemovida = disciplinas.removeIf(d -> d.getCodigo().equals(codigo));

        if (foiRemovida) {

            System.out.println(" Disciplina com código " + codigo + " removida da memória.");
        } else {
            System.out.println(" Erro: Disciplina com código " + codigo + " não encontrada para remoção.");
        }
    }
}
