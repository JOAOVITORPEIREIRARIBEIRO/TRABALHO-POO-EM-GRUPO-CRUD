package controller;


import model.Aluno;
import view.AlunoView;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class AlunoController {


    private static final List<Aluno> alunos = new ArrayList<>();

    public static void Criar() {
        Aluno aluno = new Aluno();
        AlunoView.Criar(aluno);

        if (aluno != null && aluno.getMatricula() != null && !aluno.getMatricula().trim().isEmpty()) {

            alunos.add(aluno);
            System.out.println(" Aluno criado e salvo em memória.");
        } else {
            System.out.println(" Criação de aluno cancelada ou inválida.");
        }
    }

    public static void Consultar() {
        String matricula = AlunoView.GetMatricula();


        Aluno aluno = alunos.stream()
                .filter(a -> a.getMatricula().equals(matricula))
                .findFirst()
                .orElse(null);

        AlunoView.Consultar(aluno);
    }

    public static void Listar() {

        AlunoView.Listar(alunos);
    }

    public static void Atualizar() {
        String matricula = AlunoView.GetMatricula();


        Aluno alunoParaAtualizar = alunos.stream()
                .filter(a -> a.getMatricula().equals(matricula))
                .findFirst()
                .orElse(null);

        if (alunoParaAtualizar != null) {

            AlunoView.Atualizar(alunoParaAtualizar);

            System.out.println(" Aluno atualizado com sucesso em memória.");
        } else {
            System.out.println(" Erro: Aluno com matrícula " + matricula + " não encontrado para atualização.");
        }
    }

    public static void Deletar() {
        String matricula = AlunoView.GetMatricula();


        boolean foiRemovido = alunos.removeIf(a -> a.getMatricula().equals(matricula));

        if (foiRemovido) {
            System.out.println(" Aluno com matrícula " + matricula + " removido da memória.");
        } else {
            System.out.println(" Erro: Aluno com matrícula " + matricula + " não encontrado para remoção.");
        }
    }
}