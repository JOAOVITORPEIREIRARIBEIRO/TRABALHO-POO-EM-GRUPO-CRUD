package controller;


import model.Curso;
import view.CursoView;
import java.util.ArrayList;
import java.util.List;

public class CursoController {


    private static final List<Curso> cursos = new ArrayList<>();

    public static void Criar() {
        Curso curso = new Curso();

        CursoView.Criar(curso);


        if (curso != null && curso.getCodigo() != null && !curso.getCodigo().trim().isEmpty()) {

            cursos.add(curso);
            System.out.println(" Curso criado e salvo em memória.");
        } else {
            System.out.println(" Criação de curso cancelada ou inválida.");
        }
    }

    public static void Consultar() {

        String codigo = CursoView.GetCodigo();


        Curso curso = cursos.stream()
                .filter(c -> c.getCodigo().equals(codigo))
                .findFirst()
                .orElse(null);

        CursoView.Consultar(curso);
    }

    public static void Listar() {

        CursoView.Listar(cursos);
    }

    public static void Atualizar() {
        String codigo = CursoView.GetCodigo();


        Curso cursoParaAtualizar = cursos.stream()
                .filter(c -> c.getCodigo().equals(codigo))
                .findFirst()
                .orElse(null);

        if (cursoParaAtualizar != null) {

            CursoView.Atualizar(cursoParaAtualizar);

            System.out.println(" Curso atualizado com sucesso em memória.");
        } else {
            System.out.println(" Erro: Curso com código " + codigo + " não encontrado para atualização.");
        }
    }

    public static void Deletar() {
        String codigo = CursoView.GetCodigo();


        boolean foiRemovido = cursos.removeIf(c -> c.getCodigo().equals(codigo));

        if (foiRemovido) {
            System.out.println(" Curso com código " + codigo + " removido da memória.");
        } else {
            System.out.println(" Erro: Curso com código " + codigo + " não encontrado para remoção.");
        }
    }
}
