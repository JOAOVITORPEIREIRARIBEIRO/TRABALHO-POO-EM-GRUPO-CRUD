package view;

public class MenuView {

    public static void print() {
        System.out.println("Menu");
        System.out.println("-------------------------");
        System.out.println("1 - Gerenciar Alunos");
        System.out.println("2 - Gerenciar Cursos");
        System.out.println("3 - Gerenciar Disciplinas");
        System.out.println("4 - Sair");
        System.out.println("-------------------------");
        System.out.print("Opção: ");
    }
}
